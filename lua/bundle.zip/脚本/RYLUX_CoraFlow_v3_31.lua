-- CoraFlow v3.31 profile for RYLUX's built-in Lua workflow.
-- This module intentionally configures existing RYLUX routines; it does not
-- attempt to execute a CoraFlow JSON graph inside RYLUX.
local M = {}

local values = {
  ["自动战斗"] = "true",
  ["是否队长"] = "2",
  ["挂机点地图"] = "0",
  ["挂机点x"] = "100",
  ["挂机点y"] = "200",
  ["卖货地图"] = "0",
  ["挂机不移动秒"] = "60",
  ["背包保留重量"] = "28",
  ["背包保留格子"] = "4",
  ["背包检测间隔秒"] = "60",
  ["清包前整理"] = "false",
  ["检测修理装备"] = "false",
  ["出售装备"] = "true",
  ["保护装备不出售"] = "false",
  ["出售装备二次确认"] = "false",
  ["出售装备品质上限"] = "0",
  ["出售装备品质_白色"] = "true",
  ["出售装备品质_蓝色"] = "true",
  ["出售装备品质_绿色"] = "false",
  ["出售装备品质_黄色"] = "false",
  ["出售装备品质_橙色"] = "false",
  ["保留蓝条数量"] = "1",
  ["回蓝>="] = "true",
  ["保留回蓝数值"] = "0",
  ["魔法出招>="] = "false",
  ["保留魔法出招数值"] = "0",
  ["武器出招>="] = "false",
  ["保留武器出招数值"] = "0",
  ["允许出售物品"] = "false",
  ["允许购买物品"] = "false",
  ["购买小红"] = "true",
  ["购买小蓝"] = "true",
  ["红的数量低于"] = "2",
  ["蓝的数量低于"] = "2",
  ["购买红的数量"] = "5",
  ["购买蓝的数量"] = "5",
  ["出售全部红"] = "false",
  ["出售全部蓝"] = "false",
  ["红的数量高于"] = "20",
  ["蓝的数量高于"] = "20"
}

function M.apply(data)
  if type(data) ~= "table" then data = {} end
  for key, value in pairs(values) do
    data[key] = value
  end
  data["RYLUX工作流配置"] = "CoraFlow_v3.31"
  return data
end

return M