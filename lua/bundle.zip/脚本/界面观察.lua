-- One read-only observation pass for the 610 sandbox game screen.
-- It deliberately performs no OCR and no touch actions. A single captured
-- frame is shared by all checks; uncertain or conflicting frames are unknown.

local function unknown(evidence, reason)
  return {
    state = "unknown",
    evidence = evidence or {},
    confidence = 0,
    reason = reason or "no stable page signature"
  }
end

local function observeOnFrame()
  local tz = _ENV["tz"]
  if type(tz) ~= "table" then return unknown({}, "page signatures unavailable") end

  local function pattern(key)
    local signature = tz[key]
    if signature == nil or type(_ENV["找到"]) ~= "function" then return false end
    local ok, matched = pcall(_ENV["找到"], signature)
    return ok and (matched == true or tonumber(matched) ~= nil and tonumber(matched) > 0)
  end

  local function loginButton(key)
    if type(_ENV["登录_找素材按钮"]) ~= "function" then return nil end
    local ok, x, y = pcall(_ENV["登录_找素材按钮"], key)
    if not ok or tonumber(x) == nil or tonumber(y) == nil then return nil end
    return {x = tonumber(x), y = tonumber(y)}
  end

  local function imageButton(path, left, top, right, bottom, offsetX, offsetY)
    if type(_ENV["findPic"]) ~= "function" then return nil end
    local ok, matched, x, y = pcall(_ENV["findPic"], left, top, right, bottom,
        path, "101010", 0, 0.84)
    if not ok or tonumber(matched) == nil or tonumber(matched) <= 0
        or tonumber(x) == nil or tonumber(y) == nil then return nil end
    return {x = tonumber(x) + offsetX, y = tonumber(y) + offsetY}
  end

  -- All fast-state templates share exactly two fixed 128x128 reference ROIs.
  -- Compare every known page template in the primary ROI first. Do not scan
  -- page-specific screen areas here. Only when no primary template matches do
  -- we compare the same state set in the one secondary ROI.
  local function regionMatches(path, left, top)
    if type(_ENV["findPic"]) ~= "function" then return false end
    local ok, matched = pcall(_ENV["findPic"], left, top, left + 128, top + 128,
        path, "000000", 0, 0.84)
    return ok and tonumber(matched) ~= nil and tonumber(matched) > 0
  end

  local fastStates = {
    {state = "terms", name = "条款"},
    {state = "account_login", name = "账号"},
    {state = "server_select", name = "选服"},
    {state = "role_select", name = "选角"},
    {state = "world", name = "主界面"},
    {state = "activity", name = "活动"},
    {state = "bag", name = "背包"},
    {state = "shop", name = "商店"},
    {state = "dialogue", name = "对话"}
  }

  local function matchFastState(suffix, left, top)
    -- Recheck the previous state first to make the stable-screen path one
    -- template comparison. The scan still stays inside the same single ROI.
    local previous = tostring(_ENV["当前页面"] or "")
    for _, candidate in ipairs(fastStates) do
      if candidate.state == previous
          and regionMatches("素材库/快速状态区_" .. candidate.name .. "_" .. suffix .. ".png", left, top) then
        return candidate
      end
    end
    for _, candidate in ipairs(fastStates) do
      if candidate.state ~= previous
          and regionMatches("素材库/快速状态区_" .. candidate.name .. "_" .. suffix .. ".png", left, top) then
        return candidate
      end
    end
    return nil
  end

  local function result(state, evidence, confidence, button, recoveryButton)
    return {
      state = state,
      evidence = evidence,
      confidence = confidence,
      button = button,
      recoveryButton = recoveryButton
    }
  end

  local fastState = matchFastState("主", 896, 224)
  local fastRegion = "主区"
  if fastState == nil then
    fastState = matchFastState("备", 384, 576)
    fastRegion = "备用区"
  end
  if fastState ~= nil then
    local state = fastState.state
    local evidence = {"快速状态区" .. fastRegion .. ":" .. fastState.name}
    if state == "terms" then
      local termsButton = imageButton("素材库/汉化条款同意按钮.png", 380, 550, 580, 650, 98, 40)
      return result(state, evidence, 0.84, termsButton)
    end
    if state == "account_login" then
      local accountLogin = loginButton("登录")
      return result(state, evidence, 0.84, accountLogin)
    end
    if state == "server_select" then
      local serverConfirm = imageButton("素材库/汉化服务器确认按钮.png", 650, 600, 870, 720, 102, 43)
      local serverEnter = loginButton("进入游戏")
      return result(state, evidence, 0.84, serverEnter or serverConfirm)
    end
    if state == "role_select" then
      local roleConfirm = loginButton("确认")
      local roleReturn = loginButton("角色返回")
      return result(state, evidence, 0.84, roleConfirm, roleReturn)
    end
    return result(state, evidence, 0.84)
  end

  local termsButton = imageButton("素材库/汉化条款同意按钮.png", 380, 550, 580, 650, 98, 40)
  if termsButton then return result("terms", {"汉化条款同意按钮"}, 1, termsButton) end

  local errorEvidence = {}
  for _, key in ipairs({"提示掉线", "提示下载出现问题", "提示服务器维护中", "提示账号使用中"}) do
    if pattern(key) then errorEvidence[#errorEvidence + 1] = key end
  end
  if #errorEvidence > 0 then return result("connection_error", errorEvidence, 0.98) end

  local serverConfirm = imageButton("素材库/汉化服务器确认按钮.png", 650, 600, 870, 720, 102, 43)
  if serverConfirm then return result("server_select", {"汉化服务器确认按钮"}, 1, serverConfirm) end
  local serverEnter = loginButton("进入游戏")
  if serverEnter then return result("server_select", {"服务器进入游戏按钮"}, 1, serverEnter) end
  if pattern("选区页面") then return result("server_select", {"选区页面"}, 0.96) end

  local accountLogin = loginButton("登录")
  if accountLogin or pattern("账号密码页面") then
    return result("account_login", accountLogin and {"汉化登录按钮"} or {"账号密码页面"},
        accountLogin and 1 or 0.96, accountLogin)
  end

  local roleConfirm = loginButton("确认")
  if roleConfirm or pattern("选角色页面") then
    local roleReturn = loginButton("角色返回")
    return result("role_select", roleConfirm and {"汉化角色确认按钮"} or {"选角色页面"},
        roleConfirm and 1 or 0.96, roleConfirm, roleReturn)
  end

  for _, item in ipairs({
      {"签到页面", "activity"},
      {"背包页面", "bag"},
      {"商店页面", "shop"},
      {"对话页面", "dialogue"},
      {"大地图页面", "map"},
      {"自动设置页面", "settings"},
      {"行为设置页面关闭按钮", "safe_modal"},
      {"新版本更新按钮", "safe_modal"},
      {"拍卖行页面", "safe_modal"},
      {"死亡有时候弹出", "safe_modal"},
      {"弹出提示或拒绝", "safe_modal"},
      {"确定输入内容", "safe_modal"}
    }) do
    if pattern(item[1]) then return result(item[2], {item[1]}, 0.96) end
  end

  local skill = pattern("切换技能按钮")
  local settings = pattern("设置按钮")
  if skill and settings then
    return result("world", {"切换技能按钮", "设置按钮"}, 0.98)
  end
  local partial = {}
  if skill then partial[#partial + 1] = "切换技能按钮" end
  if settings then partial[#partial + 1] = "设置按钮" end
  if #partial > 0 then return unknown(partial, "world needs two independent signatures") end
  return unknown({})
end

_ENV["观察当前界面"] = function()
  -- The host API is keepCapture/releaseCapture. Holding one frame is critical:
  -- otherwise each findPic/findColor call silently captures a new screenshot,
  -- so one classification pass can mix different UI states and burn latency.
  if type(_ENV["keepCapture"]) ~= "function"
      or type(_ENV["releaseCapture"]) ~= "function" then
    local frame = unknown({}, "stable screenshot API unavailable")
    _ENV["当前页面"] = frame.state
    return frame
  end
  local captureOk = pcall(_ENV["keepCapture"])
  if not captureOk then
    local frame = unknown({}, "screenshot capture failed")
    _ENV["当前页面"] = frame.state
    return frame
  end

  local ok, observation = pcall(observeOnFrame)
  pcall(_ENV["releaseCapture"])
  if not ok or type(observation) ~= "table" then
    observation = unknown({}, "page recognition failed")
  end
  _ENV["当前页面"] = observation.state or "unknown"
  return observation
end

return _ENV["观察当前界面"]
