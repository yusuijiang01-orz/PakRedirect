-- Idempotent auto-hunt state control shared by farming and travel/cleanup.
-- A tap is issued only when exactly one visible state signature is present,
-- then the requested state must be observed before the action is accepted.
local pendingTarget, pendingSince = nil, nil

function L0_1(targetEnabled, reason)
  if targetEnabled ~= true and targetEnabled ~= false then
    return false, "自动战斗目标状态无效"
  end
  if not _ENV["在主页面"]() then
    return false, "当前不在游戏主界面"
  end

  local on = _ENV["找到"](tz["自动挂机按钮_已开启"])
  local off = _ENV["找到"](tz["自动挂机按钮_未开启"])
  if on == off then
    return false, "自动战斗状态未识别"
  end
  if on == targetEnabled then
    pendingTarget, pendingSince = nil, nil
    return true
  end

  local now = tickCount()
  if pendingTarget == targetEnabled and pendingSince ~= nil
      and now - pendingSince < 2000 then
    return false, "自动战斗切换待确认"
  end

  local button = targetEnabled and tz["自动挂机按钮_未开启"] or tz["自动挂机按钮_已开启"]
  local action = (reason and tostring(reason) or "自动战斗")
      .. (targetEnabled and "开启" or "关闭")
  if not _ENV["找到点击"]("@@" .. action, button) then
    return false, "自动战斗按钮未找到"
  end
  pendingTarget, pendingSince = targetEnabled, tickCount()

  for _ = 1, 10 do
    sleep(100)
    if not _ENV["在主页面"]() then
      pendingTarget, pendingSince = nil, nil
      return false, "切换后游戏界面已变化"
    end
    on = _ENV["找到"](tz["自动挂机按钮_已开启"])
    off = _ENV["找到"](tz["自动挂机按钮_未开启"])
    if on ~= off and on == targetEnabled then
      pendingTarget, pendingSince = nil, nil
      return true
    end
  end
  return false, "自动战斗切换未确认"
end

_ENV["设置自动战斗状态"] = L0_1
return L0_1
